package javathreads.examples.ch08.example4;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
